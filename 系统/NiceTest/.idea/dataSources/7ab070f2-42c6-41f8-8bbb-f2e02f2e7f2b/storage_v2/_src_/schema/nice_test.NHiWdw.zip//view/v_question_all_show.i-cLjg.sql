create definer = root@localhost view v_question_all_show as select md5(concat('choose', `nice_test`.`question_choose`.`id`))  AS `id`,
                                                                   if((`nice_test`.`question_choose`.`type` = 0), '单选', '多选') AS `type`,
                                                                   `nice_test`.`question_choose`.`topic`                      AS `topic`,
                                                                   `nice_test`.`question_choose`.`keyword`                    AS `keyword`,
                                                                   `nice_test`.`question_choose`.`createUser`                 AS `createUser`,
                                                                   `nice_test`.`question_choose`.`createUserId`               AS `createUserId`,
                                                                   `nice_test`.`question_choose`.`createDate`                 AS `createDate`
                                                            from `nice_test`.`question_choose`
                                                            union
                                                            select md5(concat('completion', `nice_test`.`question_completion`.`id`)) AS `id`,
                                                                   '填空'                                                              AS `type`,
                                                                   `nice_test`.`question_completion`.`topic`                         AS `topic`,
                                                                   `nice_test`.`question_completion`.`keyword`                       AS `keyword`,
                                                                   `nice_test`.`question_completion`.`createUser`                    AS `createUser`,
                                                                   `nice_test`.`question_completion`.`createUserId`                  AS `createUserId`,
                                                                   `nice_test`.`question_completion`.`createDate`                    AS `createDate`
                                                            from `nice_test`.`question_completion`
                                                            union
                                                            select md5(concat('judge', `nice_test`.`question_judge`.`id`)) AS `id`,
                                                                   '判断'                                                    AS `type`,
                                                                   `nice_test`.`question_judge`.`topic`                    AS `topic`,
                                                                   `nice_test`.`question_judge`.`keyword`                  AS `keyword`,
                                                                   `nice_test`.`question_judge`.`createUser`               AS `createUser`,
                                                                   `nice_test`.`question_judge`.`createUserId`             AS `createUserId`,
                                                                   `nice_test`.`question_judge`.`createDate`               AS `createDate`
                                                            from `nice_test`.`question_judge`
                                                            union
                                                            select md5(concat('jquiz', `nice_test`.`question_jquiz`.`id`)) AS `id`,
                                                                   '简答'                                                    AS `type`,
                                                                   `nice_test`.`question_jquiz`.`topic`                    AS `topic`,
                                                                   `nice_test`.`question_jquiz`.`keyword`                  AS `keyword`,
                                                                   `nice_test`.`question_jquiz`.`createUser`               AS `createUser`,
                                                                   `nice_test`.`question_jquiz`.`createUserId`             AS `createUserId`,
                                                                   `nice_test`.`question_jquiz`.`createDate`               AS `createDate`
                                                            from `nice_test`.`question_jquiz`;

-- comment on column v_question_all_show.topic not supported: the topic of question

-- comment on column v_question_all_show.keyword not supported: the keyword of question

-- comment on column v_question_all_show.createUser not supported: create user

-- comment on column v_question_all_show.createUserId not supported: the id of create user

-- comment on column v_question_all_show.createDate not supported: the add time of question

